const groups = {
  OWNER: `.mode .settings .password .setprefix .delprefix .setpp .setbotbio .autobio .autostatus .autotyping .autorecording .autoreact .anticall .antidelete .antiviewonce .addsudo .delsudo .sudolist .block .unblock .ban .unban .save .schedulestatus .chatbot .clearsession .cleartmp .pair .checkidch`,
  BOT: `.help .menu .owner .ping .alive .runtime .repo`,
  GROUP: `.add .kick .kickall .promote .demote .mute .unmute .lockgroup .unlockgroup .revoke .grouplink .setname .setdesc .setgcpp .gcstatus .creategc .leavegc .groupinfo .staff .jid .tagall .tag .hidetag .tagadmins .online .onlineusers .onlineadmins .onlinestats .welcome .goodbye .rules .poll .afk .couple .antilink .antitag .antigroupmention .antigroupstatus .antibot .antibadword .slowmode .warn .warnings`,
  AI: `.ai .gpt .gemini .imagine .flux .dalle .txt2video .sora .imageedit`,
  DOWNLOADER: `.play .song .music .ytmp3 .mp3 .ytmp4 .video .instagram .tiktok .tt .facebook .fb .pinterest .anime .gitclone .apk .pixabay .gif .tourl`,
  AUDIO: `.bass .deep .blown .earrape .fast .slow .fat .squirrel .nightcore .robot .areverse .tomp3 .tts`,
  CONVERTER: `.sticker .s .simage .toimg .removebg .upscale .take .attp .qc .emojimix .tgsticker .blur .meme .getpp .wasted .character`,
  "LOGO MAKER": `.fancy .gfx .gfx2 .gfx3 .gfx4 .gfx5 .gfx6 .gfx7 .gfx8 .gfx9 .gfx10 .gfx11 .gfx12 .metallic .ice .snow .impressive .matrix .neon .light .devil .purple .thunder .leaves .1917 .arena .hacker .sand .blackpink .glitch .fire`,
  TOOLS: `.ss .ssweb .translate .tr .qrcode .qr .shorturl .urlshortener .calculator .calc .hash .base64 .binary .encrypt .decrypt .timestamp .currency .crypto .weather .news .livescore .reminder .lyrics .count .reverse .case .palindrome .age .vv .vv2 .delete .savecontact .device .netflix`,
  GAMES: `.trivia .scramble .wordle .hangman .guess .ttt .tictactoe .wyr .rps .slots .truth .dare .riddle .8ball .dice .coin .random .pick`,
  FUN: `.joke .fact .quote .compliment .insult .roast .flirt .ship .simp .stupid .shayari .goodnight .roseday .iloveyou`,
  PIES: `.pies .india .china .japan .korea .thai .malaysia`,
  PREMIUM: `.premium .setbotpp .autoreply .away .schedule .filter .persona .ghost`
};
const registry = Object.fromEntries(Object.entries(groups).map(([category, line]) => [
  category, [...new Set(line.trim().split(/\s+/))].map(name => ({ name, category }))
]));
const allCommands = Object.values(registry).flat();
const aliases = new Map();
for (const item of allCommands) aliases.set(item.name.slice(1), item);
module.exports = { registry, allCommands, aliases };
