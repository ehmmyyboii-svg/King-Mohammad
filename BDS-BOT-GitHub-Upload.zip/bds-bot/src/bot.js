const fs = require("fs");
const path = require("path");
const pino = require("pino");
const {
  default: makeWASocket, useMultiFileAuthState, DisconnectReason,
  fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");
const { registry, aliases, allCommands } = require("./commands");

const authDir = path.join(__dirname, "..", "auth_info_bds");
let sock = null, connecting = false, pairingBusy = false, connection = "disconnected";
let connectedAt = null, lastError = null, startedAt = Date.now();
let pairingCodeIssuedAt = null;

function getBotStatus() {
  return {
    name: process.env.BOT_NAME || "BDS BOT",
    owner: process.env.BOT_OWNER_NAME || "King Muhammad",
    prefix: process.env.BOT_PREFIX || ".",
    commandCount: allCommands.length,
    connection, connected: connection === "connected",
    uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000),
    connectedAt, pairingCodeIssuedAt, lastError,
    version: require("../package.json").version
  };
}
function formatDuration(total) {
  const d = Math.floor(total / 86400), h = Math.floor(total % 86400 / 3600);
  const m = Math.floor(total % 3600 / 60), s = total % 60;
  return `${d}d ${h}h ${m}m ${s}s`;
}
function menuText() {
  const prefix = process.env.BOT_PREFIX || ".";
  const lines = [
    `╭─「 *${process.env.BOT_NAME || "BDS BOT"}* 」`,
    `│ Owner: ${process.env.BOT_OWNER_NAME || "King Muhammad"}`,
    `│ Prefix: ${prefix}`,
    `│ Commands: ${allCommands.length}`,
    `│ Uptime: ${formatDuration(Math.floor((Date.now() - startedAt) / 1000))}`,
    "╰────────────────"
  ];
  for (const [category, items] of Object.entries(registry)) {
    lines.push(`\n┏━━「 *${category}* 」`);
    lines.push(items.map(x => x.name).join("  "));
  }
  lines.push("\n\nNote: Catalogue entries without handlers are not implemented yet.");
  return lines.join("\n");
}
function isOwner(jid) {
  const configured = String(process.env.BOT_OWNER_ID || "").replace(/\D/g, "");
  const sender = String(jid || "").split("@")[0].split(":")[0].replace(/\D/g, "");
  return Boolean(configured && sender && configured === sender);
}
async function sendText(jid, text, quoted) {
  if (!sock || !jid) return;
  return sock.sendMessage(jid, { text }, quoted ? { quoted } : {});
}
async function handleMessage(msg) {
  if (!msg.message || msg.key?.fromMe) return;
  const jid = msg.key.remoteJid;
  if (!jid || jid === "status@broadcast") return;
  const content = msg.message.conversation ||
    msg.message.extendedTextMessage?.text ||
    msg.message.imageMessage?.caption ||
    msg.message.videoMessage?.caption || "";
  const prefix = process.env.BOT_PREFIX || ".";
  if (!content.startsWith(prefix)) return;
  const parts = content.slice(prefix.length).trim().split(/\s+/);
  const command = (parts.shift() || "").toLowerCase();
  const args = parts;
  const sender = msg.key.participant || jid;
  const started = Date.now();

  try {
    if (["help", "menu"].includes(command)) return sendText(jid, menuText(), msg);
    if (command === "ping") return sendText(jid, `🏓 Pong: ${Date.now() - started}ms`, msg);
    if (command === "alive") return sendText(jid, `✅ ${process.env.BOT_NAME || "BDS BOT"} is online.\nOwner: ${process.env.BOT_OWNER_NAME || "King Muhammad"}\nUptime: ${formatDuration(Math.floor((Date.now() - startedAt) / 1000))}`, msg);
    if (command === "runtime") return sendText(jid, `⏱️ Uptime: ${formatDuration(Math.floor((Date.now() - startedAt) / 1000))}`, msg);
    if (command === "owner") {
      const owner = String(process.env.BOT_OWNER_ID || "").replace(/\D/g, "");
      return sendText(jid, `👑 ${process.env.BOT_OWNER_NAME || "King Muhammad"}${owner ? `\nWhatsApp: wa.me/${owner}` : ""}`, msg);
    }
    if (command === "repo") return sendText(jid, "BDS BOT source repository: add your GitHub repository URL to README.md and this handler when ready.", msg);
    if (command === "mode" || command === "settings" || command === "setprefix") {
      if (!isOwner(sender)) return sendText(jid, "⛔ Owner-only command.", msg);
      if (command === "setprefix" && args[0] && args[0].length <= 3) {
        process.env.BOT_PREFIX = args[0];
        return sendText(jid, `✅ Prefix changed to ${args[0]} for this running process. Set BOT_PREFIX in your host environment to keep it after restart.`, msg);
      }
      return sendText(jid, `Settings\nPrefix: ${process.env.BOT_PREFIX || "."}\nConnection: ${connection}\nCommand catalogue: ${allCommands.length}`, msg);
    }
    if (command === "jid") return sendText(jid, `Chat JID: ${jid}\nSender JID: ${sender}`, msg);
    if (command === "groupinfo" && jid.endsWith("@g.us")) {
      const metadata = await sock.groupMetadata(jid);
      return sendText(jid, `👥 ${metadata.subject}\nMembers: ${metadata.participants.length}\nOwner: ${metadata.owner || "Unknown"}`, msg);
    }
    if (command === "poll") {
      const text = args.join(" ");
      if (!text.includes("|")) return sendText(jid, "Usage: .poll Question | Option 1 | Option 2", msg);
      const [name, ...values] = text.split("|").map(v => v.trim());
      if (values.length < 2) return sendText(jid, "Add at least two options. Example: .poll Favourite colour | Green | Blue", msg);
      return sock.sendMessage(jid, { poll: { name, values: values.slice(0, 12), selectableCount: 1 } }, { quoted: msg });
    }
    if (command === "count") return sendText(jid, `Characters: ${args.join(" ").length}\nWords: ${args.join(" ").trim() ? args.join(" ").trim().split(/\s+/).length : 0}`, msg);
    if (command === "reverse") return sendText(jid, args.join(" ").split("").reverse().join(""), msg);
    if (command === "case") return sendText(jid, args.join(" ").toUpperCase(), msg);
    if (command === "8ball") {
      const answers = ["Yes.", "No.", "Maybe.", "Ask again later.", "It looks promising.", "I can't tell right now."];
      return sendText(jid, `🎱 ${answers[Math.floor(Math.random() * answers.length)]}`, msg);
    }
    if (command === "dice") return sendText(jid, `🎲 ${1 + Math.floor(Math.random() * 6)}`, msg);
    if (command === "coin") return sendText(jid, Math.random() < 0.5 ? "🪙 Heads" : "🪙 Tails", msg);
    if (command === "random") return sendText(jid, `🎲 ${Math.floor(Math.random() * 100) + 1}`, msg);
    if (command === "rps") {
      const user = (args[0] || "").toLowerCase();
      if (!["rock", "paper", "scissors"].includes(user)) return sendText(jid, "Usage: .rps rock|paper|scissors", msg);
      const bot = ["rock", "paper", "scissors"][Math.floor(Math.random() * 3)];
      const outcome = user === bot ? "Tie!" : ((user === "rock" && bot === "scissors") || (user === "paper" && bot === "rock") || (user === "scissors" && bot === "paper")) ? "You win!" : "I win!";
      return sendText(jid, `You: ${user}\nMe: ${bot}\n${outcome}`, msg);
    }
    if (command === "trivia") return sendText(jid, "Trivia handler is a starter placeholder. It is listed but not implemented yet.", msg);
    if (aliases.has(command)) return sendText(jid, `⚠️ ${prefix}${command} is in the BDS BOT catalogue but its handler is not implemented yet.`, msg);
  } catch (err) {
    console.error("Message handler error:", err.message);
    await sendText(jid, "Sorry, that command failed. Please try again later.", msg).catch(() => {});
  }
}
async function startBot() {
  if (connecting || sock) return;
  connecting = true;
  try {
    fs.mkdirSync(authDir, { recursive: true });
    const { state, saveCreds } = await useMultiFileAuthState(authDir);
    let version;
    try { ({ version } = await fetchLatestBaileysVersion()); } catch (_) {}
    sock = makeWASocket({
      auth: state,
      ...(version ? { version } : {}),
      logger: pino({ level: process.env.LOG_LEVEL || "silent" }),
      browser: ["BDS BOT", "Chrome", "1.0.0"],
      printQRInTerminal: false,
      markOnlineOnConnect: false,
      syncFullHistory: false
    });
    sock.ev.on("creds.update", saveCreds);
    sock.ev.on("connection.update", async update => {
      const { connection: stateName, lastDisconnect } = update;
      if (stateName === "open") {
        connection = "connected"; connectedAt = new Date().toISOString(); lastError = null;
        console.log("BDS BOT connected to WhatsApp.");
      } else if (stateName === "connecting") connection = "connecting";
      else if (stateName === "close") {
        connection = "disconnected";
        const code = lastDisconnect?.error?.output?.statusCode;
        const loggedOut = code === DisconnectReason.loggedOut;
        lastError = loggedOut ? "WhatsApp logged out. Remove old auth only if you intend to pair again." : "Connection closed; reconnecting.";
        sock = null;
        if (!loggedOut) setTimeout(() => startBot().catch(e => console.error(e.message)), 3000);
      }
    });
    sock.ev.on("messages.upsert", async ({ messages, type }) => {
      if (type !== "notify") return;
      for (const msg of messages) await handleMessage(msg);
    });
  } catch (err) {
    sock = null; connection = "disconnected"; lastError = err.message;
    console.error("Unable to start Baileys:", err.message);
  } finally { connecting = false; }
}
async function requestPairing(phone) {
  if (pairingBusy) throw new Error("A pairing request is already running. Wait a moment and try again.");
  pairingBusy = true;
  try {
    if (!sock) await startBot();
    for (let i = 0; i < 30 && !sock; i++) await new Promise(resolve => setTimeout(resolve, 250));
    if (!sock) throw new Error("WhatsApp client could not start. Check server logs and retry.");
    if (connection === "connected") throw new Error("This bot is already connected to WhatsApp.");
    const { state } = await useMultiFileAuthState(authDir);
    if (state.creds?.registered) throw new Error("A WhatsApp session is already registered. Disconnect/log out from linked devices before requesting a new code.");
    const code = await sock.requestPairingCode(phone);
    pairingCodeIssuedAt = new Date().toISOString();
    return String(code).match(/.{1,4}/g)?.join("-") || String(code);
  } catch (err) {
    throw new Error(err.message || "Pairing request failed.");
  } finally { pairingBusy = false; }
}
async function stopBot() {
  const current = sock; sock = null; connection = "disconnected";
  if (current) {
    try { current.end(undefined); } catch (_) {}
  }
}
module.exports = { startBot, requestPairing, stopBot, getBotStatus };
