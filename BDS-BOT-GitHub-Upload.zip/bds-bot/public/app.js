const $ = (id) => document.getElementById(id);
const pages = ["home","pair","sessions","manage"];
let latestStatus = null;
function showPage(page) {
  if (!pages.includes(page)) page = "home";
  document.querySelectorAll(".page").forEach(el => el.classList.toggle("active", el.id === page));
  document.querySelectorAll(".nav-link").forEach(el => el.classList.toggle("active", el.dataset.page === page));
  $("nav").classList.remove("open");
  window.scrollTo({top:0,behavior:"smooth"});
  if (page === "manage" || page === "sessions") refreshStatus();
}
document.querySelectorAll("[data-page]").forEach(el => el.addEventListener("click", e => {
  e.preventDefault(); showPage(el.dataset.page);
}));
$("navToggle").addEventListener("click", () => $("nav").classList.toggle("open"));
document.querySelectorAll(".year").forEach(el => el.textContent = new Date().getFullYear());
$("year").textContent = new Date().getFullYear();
function duration(seconds) {
  seconds = Math.max(0, Number(seconds)||0);
  const d=Math.floor(seconds/86400), h=Math.floor(seconds%86400/3600), m=Math.floor(seconds%3600/60), s=seconds%60;
  return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m ${s}s`;
}
function setText(id, value) { const el=$(id); if(el) el.textContent = value ?? "—"; }
async function refreshStatus() {
  try {
    const res = await fetch("/api/status", {cache:"no-store"});
    if (!res.ok) throw new Error("Status request failed");
    const s = await res.json(); latestStatus = s;
    const state = s.connected ? "Connected" : (s.connection || "Disconnected");
    setText("headerStatus", state); setText("statConnection", state);
    setText("statCommands", s.commandCount); setText("statUptime", duration(s.uptimeSeconds));
    setText("statVersion", s.version); setText("heroVersion", s.version);
    setText("updatedAt", "Updated " + new Date().toLocaleTimeString());
    setText("sessionDescription", s.connected ? "WhatsApp is connected to the running bot." : "No active WhatsApp connection is confirmed yet.");
    setText("sessionState", state);
    setText("connectedAt", s.connectedAt ? "Connected since " + new Date(s.connectedAt).toLocaleString() : "");
    setText("manageChip", state); setText("manageConnection", state);
    setText("manageMessage", s.lastError || (s.connected ? "The Baileys socket is connected." : "Pair your WhatsApp while the server is running."));
    setText("detailName", s.name); setText("detailOwner", s.owner); setText("detailPrefix", s.prefix);
    setText("detailCommands", s.commandCount); setText("detailUptime", duration(s.uptimeSeconds)); setText("detailVersion", s.version);
  } catch (_) {
    setText("headerStatus","Server offline"); setText("statConnection","Offline");
    setText("manageConnection","Unavailable"); setText("manageMessage","Could not read status from this server.");
  }
}
function message(el, text, kind) {
  el.className = "message " + kind; el.textContent = text;
}
$("pairBtn").addEventListener("click", async () => {
  const phone = $("phone").value.replace(/\D/g,""), token = $("token").value;
  const output = $("pairMessage");
  if (!/^\d{8,15}$/.test(phone)) return message(output,"Enter a valid phone number with country code (8–15 digits).","error");
  if (!token) return message(output,"Enter the admin token configured on your server. It is not saved by this page.","error");
  const btn=$("pairBtn"); btn.disabled=true; btn.textContent="Requesting code…";
  try {
    const res=await fetch("/api/pair",{method:"POST",headers:{"Content-Type":"application/json","x-admin-token":token},body:JSON.stringify({phone})});
    const data=await res.json();
    if(!res.ok||!data.ok) throw new Error(data.error||"Pairing request failed.");
    message(output,`PAIRING CODE\n\n${data.code}\n\n${data.message}\n\nIf it expires, request a new code. Keep this code private.`,"success");
    await refreshStatus();
  } catch(err) { message(output,err.message||"Could not request pairing code.","error"); }
  finally { btn.disabled=false; btn.innerHTML='Generate real pairing code <span>→</span>'; }
});
$("disconnectBtn").addEventListener("click", async () => {
  const token=window.prompt("Enter your BOT_ADMIN_TOKEN to disconnect the bot socket:");
  if(!token) return;
  const btn=$("disconnectBtn"); btn.disabled=true; btn.textContent="Disconnecting…";
  try {
    const res=await fetch("/api/disconnect",{method:"POST",headers:{"Content-Type":"application/json","x-admin-token":token},body:"{}"});
    const data=await res.json();
    if(!res.ok||!data.ok) throw new Error(data.error||"Disconnect failed.");
    toast("Bot socket disconnected. Credentials were not deleted.");
    await refreshStatus();
  } catch(err) { toast(err.message||"Disconnect failed."); }
  finally {btn.disabled=false;btn.textContent="Disconnect socket";}
});
let toastTimer;
function toast(text) { const el=$("toast"); el.textContent=text; el.classList.remove("hidden"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.add("hidden"),3500); }
refreshStatus(); setInterval(refreshStatus,10000);
